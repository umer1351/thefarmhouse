/*!========================================================================
 * ======================================================================== */

;(function($){

    $.iconset_kw_presentup = {
        iconClass: 'kw_presentup',
        iconClassFix: 'flaticon-',
        icons: [
			'',
			'confetti',
			'cheers',
			'fireworks',
			'cake',
			'pizza',
			'balloons',
			'beer',
			'camera',
			'champagne',
			'stage',
			'gift',
			'engagement',
			'wedding-couple',
			'glasses',
			'newlyweds',
			'wedding-location',
			'restaurant',
			'dancing',
			'flamenco-dancers-sexy-couple-silhouettes',
			'marriage-couple',
			'party-dj',
			'man-in-a-party-dancing-with-people',
			'fireworks-1',
			'cheers-1',
			'party',
			'dinner-table',
			'gift-1',
			'balloons-1',
			'beer-1',
			'newly-married-couple',
			'businessmen-having-a-group-conference',
			'mask'
		]};
    
})(jQuery);
